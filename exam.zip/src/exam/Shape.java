package exam;

public abstract class Shape {
	public Shape() {
		
	}
	
	public double area() {
		return 0;
	}	
}
