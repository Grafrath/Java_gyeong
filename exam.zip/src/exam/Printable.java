package exam;

public interface Printable {
	default void print(String message) {
		
	}
}
