package exam;

public class ConsolePrinter implements Printable {
	public void print(String message) {
		System.out.println(message);
	}
}
