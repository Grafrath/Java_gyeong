package exam;

public class Printer {
	public void print(String message) {
		System.out.println(message);
	}
	
	public void print(int value) {
		System.out.println("정수: " + value);
	}
	
	public void print(double value) {
		System.out.println("실수: " + value);
	}
}
