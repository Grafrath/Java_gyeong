package exam;

public class Animal {
	
	public void sound() {
		System.out.println("동물이 소리를 냅니다.");
	}

}
