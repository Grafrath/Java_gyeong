package exam;

public class Dog extends Animal {
	
	public void sound() {
		System.out.println("멍멍");
	}

}