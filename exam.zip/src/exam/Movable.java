package exam;

public interface Movable {
	default void move(int x, int y) {
		
	}
}
