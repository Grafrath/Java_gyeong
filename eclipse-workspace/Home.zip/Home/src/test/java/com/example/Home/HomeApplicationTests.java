package com.example.Home;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
